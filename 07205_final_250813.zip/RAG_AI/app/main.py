import streamlit as st
from components.sidebar import render_sidebar
from workflow.state import AgentType, CountryReviewState
from workflow.graph import create_country_review_graph
from utils.state_manager import init_session_state, reset_session_state
from database.repository import debate_repository
from config.email_config import get_email_config, is_email_configured
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import re

def send_email_share(recipient_email: str, country: str, pros: str, cons: str, conclusion: str, itinerary: str, alternatives: str) -> bool:
    """이메일로 조사 결과를 공유하는 함수"""
    try:
        # 이메일 설정 확인
        if not is_email_configured():
            st.error("이메일 설정이 완료되지 않았습니다. 관리자에게 문의하세요.")
            return False
        
        sender_email, sender_password = get_email_config()
        
        # 이메일 내용 구성
        subject = f"🌏 {country} 여행지 조사 결과"
        
        # HTML 형식의 이메일 내용
        html_content = f"""
        <html>
        <body>
            <h1>🌏 {country} 여행지 조사 결과</h1>
            
            <h2>장점</h2>
            <p>{pros}</p>
            
            <h2>단점</h2>
            <p>{cons}</p>
            
            <h2>결론</h2>
            <p>{conclusion}</p>
            
            <h2>추천 여행 코스</h2>
            <p>{itinerary}</p>
            
            <h2>추가팁: 대체 여행지</h2>
            <p>{alternatives}</p>
            
            <hr>
            <p><small>이 메일은 AI 여행지 조사 시스템에서 자동으로 생성되었습니다.</small></p>
        </body>
        </html>
        """
        
        # 이메일 메시지 생성
        msg = MIMEMultipart('alternative')
        msg['From'] = sender_email
        msg['To'] = recipient_email
        msg['Subject'] = subject
        
        # HTML 내용 추가
        html_part = MIMEText(html_content, 'html')
        msg.attach(html_part)
        
        # 이메일 전송
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(msg)
        server.quit()
        
        return True
    except Exception as e:
        st.error(f"이메일 전송 중 오류가 발생했습니다: {str(e)}")
        return False

def validate_email(email: str) -> bool:
    """이메일 주소 유효성 검사"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def render_share_popup():
    """공유 팝업 렌더링"""
    with st.container():
        st.markdown("### 📧 이메일로 공유하기")
        
        # 이메일 설정 확인
        if not is_email_configured():
            st.warning("⚠️ 이메일 설정이 완료되지 않았습니다.")
            st.info("이메일 공유 기능을 사용하려면 환경변수를 설정해주세요:")
            st.code("EMAIL_SENDER=your-email@gmail.com\nEMAIL_PASSWORD=your-app-password")
            
            if st.button("❌ 닫기"):
                st.session_state.show_share_popup = False
                st.rerun()
            return
        
        # 이메일 입력
        email = st.text_input("받는 사람 이메일 주소:", placeholder="example@email.com")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("📤 보내기", type="primary"):
                if not email:
                    st.error("이메일 주소를 입력해주세요.")
                elif not validate_email(email):
                    st.error("올바른 이메일 주소를 입력해주세요.")
                else:
                    # 이메일 전송 시도
                    success = send_email_share(
                        email,
                        st.session_state.country,
                        st.session_state.pros,
                        st.session_state.cons,
                        st.session_state.conclusion,
                        st.session_state.itinerary,
                        st.session_state.alternatives
                    )
                    
                    if success:
                        st.success("이메일이 성공적으로 전송되었습니다!")
                        st.session_state.show_share_popup = False
                    else:
                        st.error("이메일 전송에 실패했습니다. 다시 시도해주세요.")
        
        with col2:
            if st.button("❌ 취소"):
                st.session_state.show_share_popup = False
                st.rerun()

def start_country_review():
    country = st.session_state.ui_country
    review_graph = create_country_review_graph()
    initial_state: CountryReviewState = {
        "country": country,
        "pros": "",
        "cons": "",
        "conclusion": "",
        "itinerary": "",
        "alternatives": "",
        "docs": {},
        "contexts": {},
    }
    with st.spinner("여행지 조사 중입니다... 완료까지 잠시 기다려주세요."):
        result = review_graph.invoke(initial_state)
        st.session_state.country = result["country"]
        st.session_state.pros = result["pros"]
        st.session_state.cons = result["cons"]
        st.session_state.conclusion = result["conclusion"]
        st.session_state.itinerary = result["itinerary"]
        st.session_state.alternatives = result["alternatives"]
        st.session_state.docs = result.get("docs", {})
        
        # 이력을 데이터베이스에 저장
        try:
            # 메시지 형태로 저장할 데이터 구성 (여행 코스와 대체 여행지는 별도 줄로 저장)
            messages = [
                {"role": "user", "content": f"{country} 여행 조사 요청"},
                {"role": "assistant", "content": f"장점: {result['pros']}\n단점: {result['cons']}\n결론: {result['conclusion']}\n추천 여행 코스:\n{result['itinerary']}\n대체 여행지:\n{result['alternatives']}"}
            ]
            
            # 이력 저장
            debate_repository.save(
                topic=f"{country} 여행 조사",
                rounds=1,
                messages=messages,
                docs=result.get("docs", {})
            )
            st.success("조사 결과가 이력에 저장되었습니다.")
        except Exception as e:
            st.error(f"이력 저장 중 오류가 발생했습니다: {str(e)}")
    
    st.session_state.app_mode = "results"
    st.rerun()

def render_source_materials():
    with st.expander("참조 데이터 보기"):
        st.subheader("장점 관련 참조")
        for i, doc in enumerate(st.session_state.docs.get(AgentType.PROS, [])[:3]):
            if hasattr(doc, 'metadata') and doc.metadata.get('source'):
                url = doc.metadata['source']
                # URL이 http로 시작하는지 확인하고, 그렇지 않으면 https:// 추가
                if not url.startswith(('http://', 'https://')):
                    url = 'https://' + url
                st.markdown(f"**문서 {i+1}**")
                st.markdown(f"🔗 [원본 링크]({url})")
                st.code(url, language="text")
            else:
                st.markdown(f"**문서 {i+1}**")
            # Document 객체인지 문자열인지 확인
            if hasattr(doc, 'page_content'):
                content = doc.page_content
            else:
                content = str(doc)
            st.text(content[:300] + "..." if len(content) > 300 else content)
            st.divider()
        st.subheader("단점 관련 참조")
        for i, doc in enumerate(st.session_state.docs.get(AgentType.CONS, [])[:3]):
            if hasattr(doc, 'metadata') and doc.metadata.get('source'):
                url = doc.metadata['source']
                # URL이 http로 시작하는지 확인하고, 그렇지 않으면 https:// 추가
                if not url.startswith(('http://', 'https://')):
                    url = 'https://' + url
                st.markdown(f"**문서 {i+1}**")
                st.markdown(f"🔗 [원본 링크]({url})")
                st.code(url, language="text")
            else:
                st.markdown(f"**문서 {i+1}**")
            # Document 객체인지 문자열인지 확인
            if hasattr(doc, 'page_content'):
                content = doc.page_content
            else:
                content = str(doc)
            st.text(content[:300] + "..." if len(content) > 300 else content)
            st.divider()
        st.subheader("여행 코스 관련 참조")
        for i, doc in enumerate(st.session_state.docs.get(AgentType.ITINERARY, [])[:3]):
            if hasattr(doc, 'metadata') and doc.metadata.get('source'):
                url = doc.metadata['source']
                # URL이 http로 시작하는지 확인하고, 그렇지 않으면 https:// 추가
                if not url.startswith(('http://', 'https://')):
                    url = 'https://' + url
                st.markdown(f"**문서 {i+1}**")
                st.markdown(f"🔗 [원본 링크]({url})")
                st.code(url, language="text")
            else:
                st.markdown(f"**문서 {i+1}**")
            # Document 객체인지 문자열인지 확인
            if hasattr(doc, 'page_content'):
                content = doc.page_content
            else:
                content = str(doc)
            st.text(content[:300] + "..." if len(content) > 300 else content)
            st.divider()
        st.subheader("대체 여행지 관련 참조")
        for i, doc in enumerate(st.session_state.docs.get(AgentType.ALTERNATIVES, [])[:3]):
            if hasattr(doc, 'metadata') and doc.metadata.get('source'):
                url = doc.metadata['source']
                # URL이 http로 시작하는지 확인하고, 그렇지 않으면 https:// 추가
                if not url.startswith(('http://', 'https://')):
                    url = 'https://' + url
                st.markdown(f"**문서 {i+1}**")
                st.markdown(f"🔗 [원본 링크]({url})")
                st.code(url, language="text")
            else:
                st.markdown(f"**문서 {i+1}**")
            # Document 객체인지 문자열인지 확인
            if hasattr(doc, 'page_content'):
                content = doc.page_content
            else:
                content = str(doc)
            st.text(content[:300] + "..." if len(content) > 300 else content)
            st.divider()

def display_country_review_results():
    st.header(f" 🗺️ {st.session_state.country}를 알아본 결과.")
    
    st.markdown("<br>", unsafe_allow_html=True)  # 한 줄 띄우기

    # 장점
    st.subheader("👍 장점")
    st.text(st.session_state.pros)
    
    # 단점
    st.subheader("👎 단점")
    st.text(st.session_state.cons)
    
    # 결론
    st.subheader("🤝 결론")
    st.text(st.session_state.conclusion)

    st.markdown("<br>", unsafe_allow_html=True)  # 한 줄 띄우기
    st.markdown("<hr>", unsafe_allow_html=True)  # 한 줄 띄우기
    st.markdown("<br>", unsafe_allow_html=True)  # 한 줄 띄우기

    # 추천 여행 코스
    st.subheader("🚕 추천 여행 코스")
    if st.session_state.itinerary:
        # 여행 코스 내용을 구조화하여 표시
        itinerary_lines = st.session_state.itinerary.split('\n')
        for line in itinerary_lines:
            line = line.strip()
            if line:
                # 숫자로 시작하는 경우 (예: "1.", "2.", "3.") 상위 depth로 간주
                if line.startswith(('1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.', '9.', '0.')):
                    st.markdown(f"{line}")
                # 특정 키워드로 시작하는 경우 상위 depth로 간주
                elif line.startswith(('###','**','•', '▶', '→', 'DAY', 'Day', '첫째날', '둘째날', '셋째날', '넷째날', '다섯째날')):
                    st.markdown(f"{line}")
                # 그 외의 경우는 일반 텍스트로 표시
                else:
                    st.text(line)

    st.markdown("<br>", unsafe_allow_html=True)  # 한 줄 띄우기
    st.markdown("<hr>", unsafe_allow_html=True)  # 한 줄 띄우기
    st.markdown("<br>", unsafe_allow_html=True)  # 한 줄 띄우기

    # 대체 여행지
    st.subheader(f"🖐️ {st.session_state.country}하고 비슷한 여기도 알아봐 (비슷한 여행지)")
    if st.session_state.alternatives:
        # 대체 여행지 내용을 구조화하여 표시
        alternatives_lines = st.session_state.alternatives.split('\n')
        for line in alternatives_lines:
            line = line.strip()
            if line:
                # 숫자로 시작하는 경우 (예: "1.", "2.", "3.") 상위 depth로 간주
                if line.startswith(('1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.', '9.', '0.')):
                    st.markdown(f"{line}")
                # 특정 키워드로 시작하는 경우 상위 depth로 간주
                elif line.startswith(('###','**','•', '▶', '→', 'DAY', 'Day', '첫째날', '둘째날', '셋째날', '넷째날', '다섯째날')):
                    st.markdown(f"{line}")
                # 그 외의 경우는 일반 텍스트로 표시
                else:
                    st.text(line)
    
    if st.session_state.docs:
        render_source_materials()
    
    # 버튼 영역
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("새 평가 시작"):
            reset_session_state()
            st.rerun()
    
    with col2:
        if st.button("📧 공유하기"):
            st.session_state.show_share_popup = True
            st.rerun()
    
    # 공유 팝업 표시
    if st.session_state.get("show_share_popup", False):
        st.markdown("---")
        render_share_popup()

def render_ui():
    st.set_page_config(page_title="여행지 알아보기", page_icon="🌏")
    st.title("🌏 빠르고 정확한 여행지 조사 🌏")
    st.markdown(
        """##### 여행지의 장단점과 결론. 추천코스, 유용한 정보를 제공합니다."""
    )

    st.markdown("<hr>", unsafe_allow_html=True)  # 한 줄 띄우기

    render_sidebar()
    current_mode = st.session_state.get("app_mode")
    if current_mode == "review":
        start_country_review()
    elif current_mode == "results":
        display_country_review_results()
    # app_mode가 False이거나 다른 값일 때는 초기 상태 (사이드바만 표시)

if __name__ == "__main__":
    init_session_state()
    # 데이터베이스 초기화
    from database.session import db_session
    db_session.initialize()
    render_ui()