import streamlit as st

from typing import Dict, Any

from components.history import render_history_ui


def render_input_form():
    with st.form("country_review_form", border=False):
        st.text_input(
            label="여행지(국가명 or 도시명)를 입력하세요:",
            value="대한민국",
            key="ui_country",
        )
        st.form_submit_button(
            "조사 시작",
            on_click=lambda: st.session_state.update({"app_mode": "review"}),
        )


def render_sidebar() -> Dict[str, Any]:
    with st.sidebar:
        # 현재 활성 탭 표시
        current_tab = st.session_state.get("sidebar_tab", 0)
        
        # 탭 생성
        tab1, tab2 = st.tabs(["여행지 조사", "조사 이력"])
        
        # 탭 내용 표시
        with tab1:
            render_input_form()
            
        with tab2:
            render_history_ui()
