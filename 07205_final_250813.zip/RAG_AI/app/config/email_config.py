import os
from typing import Optional

def get_email_config() -> tuple[Optional[str], Optional[str]]:
    """이메일 설정을 가져오는 함수"""
    # 환경변수에서 이메일 설정을 가져옴
    sender_email = os.getenv("EMAIL_SENDER")
    sender_password = os.getenv("EMAIL_PASSWORD")
    
    return sender_email, sender_password

def is_email_configured() -> bool:
    """이메일이 올바르게 설정되었는지 확인"""
    sender_email, sender_password = get_email_config()
    return sender_email is not None and sender_password is not None 