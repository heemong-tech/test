from workflow.state import CountryReviewState, AgentType
from workflow.node import pros_agent, cons_agent, conclusion_agent, itinerary_agent, alternatives_agent
from langgraph.graph import StateGraph, END

from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
import streamlit as st

def create_country_review_graph() -> StateGraph:
    workflow = StateGraph(CountryReviewState)
    # 노드 추가
    workflow.add_node(AgentType.PROS, pros_agent)
    workflow.add_node(AgentType.CONS, cons_agent)
    workflow.add_node(AgentType.CONCLUSION, conclusion_agent)
    workflow.add_node(AgentType.ITINERARY, itinerary_agent)
    workflow.add_node(AgentType.ALTERNATIVES, alternatives_agent)
    # 엣지 연결: 장점 → 단점 → 결론 → 여행 코스 → 대체 여행지 → END
    workflow.add_edge(AgentType.PROS, AgentType.CONS)
    workflow.add_edge(AgentType.CONS, AgentType.CONCLUSION)
    workflow.add_edge(AgentType.CONCLUSION, AgentType.ITINERARY)
    workflow.add_edge(AgentType.ITINERARY, AgentType.ALTERNATIVES)
    workflow.add_edge(AgentType.ALTERNATIVES, END)
    # 시작점
    workflow.set_entry_point(AgentType.PROS)

    # 그래프 컴파일
    #graph = workflow.compile()    

    #try:
    #    png_image = graph.get_graph().draw_mermaid_png()  # PNG 생성
    #    st.image(png_image, caption="Flow Diagram")      # Streamlit 화면에 출력
    #except Exception as e:
    #    st.error(f"그래프 시각화 오류: {str(e)}")

    return workflow.compile()


if __name__ == "__main__":

    graph = create_country_review_graph()

    graph_image = graph.get_graph().draw_mermaid_png()

    output_path = "country_review_graph.png"
    with open(output_path, "wb") as f:
        f.write(graph_image)

    import subprocess

    subprocess.run(["open", output_path])
