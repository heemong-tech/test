# 여행 국가 평가 상태 정의
from typing import Dict, List, TypedDict

class AgentType:
    PROS = "PROS_AGENT"   # 장점
    CONS = "CONS_AGENT"   # 단점
    CONCLUSION = "CONCLUSION_AGENT"  # 결론
    ITINERARY = "ITINERARY_AGENT"  # 여행 코스
    ALTERNATIVES = "ALTERNATIVES_AGENT"  # 대체 여행지

    @classmethod
    def to_korean(cls, role: str) -> str:
        if role == cls.PROS:
            return "장점"
        elif role == cls.CONS:
            return "단점"
        elif role == cls.CONCLUSION:
            return "결론"
        elif role == cls.ITINERARY:
            return "여행 코스"
        elif role == cls.ALTERNATIVES:
            return "대체 여행지"
        else:
            return role

class CountryReviewState(TypedDict):
    country: str
    pros: str
    cons: str
    conclusion: str
    itinerary: str
    alternatives: str
    docs: Dict[str, List]  # RAG 검색 결과 (장점/단점/결론/코스/대체지별)
    contexts: Dict[str, str]  # RAG 검색 컨텍스트 (장점/단점/결론/코스/대체지별)
