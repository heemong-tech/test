from retrieval.vector_store import search_topic
from langchain.schema import HumanMessage, SystemMessage
from utils.config import get_llm
from workflow.state import CountryReviewState, AgentType

# 장점 생성 노드
def pros_agent(state: CountryReviewState) -> CountryReviewState:
    country = state["country"]
    # RAG 검색 (장점)
    docs = search_topic(country, AgentType.PROS, f"{country} 여행 장점, 추천 이유", k=3)
    context = "\n".join([doc.page_content for doc in docs])
    # LLM 프롬프트
    prompt = f"""
    '{country}'를 여행지로 선택할 때의 장점(이점, 추천 이유)을 알려주세요. 아래 검색 결과를 참고해 구체적으로 작성하고, 인용 근거가 있으면 함께 제시하세요. 2~3문단, 각 문단 100자 이내.
    [검색 결과]\n{context}
    """
    messages = [SystemMessage(content="당신은 여행 전문가입니다."), HumanMessage(content=prompt)]
    response = get_llm().invoke(messages)
    new_state = state.copy()
    new_state["pros"] = response.content
    new_state["contexts"] = new_state.get("contexts", {})
    new_state["contexts"][AgentType.PROS] = context
    new_state["docs"] = new_state.get("docs", {})
    new_state["docs"][AgentType.PROS] = [doc.page_content for doc in docs]
    return new_state

# 단점 생성 노드
def cons_agent(state: CountryReviewState) -> CountryReviewState:
    country = state["country"]
    # RAG 검색 (단점)
    docs = search_topic(country, AgentType.CONS, f"{country} 여행 단점, 주의점, 불편함", k=3)
    context = "\n".join([doc.page_content for doc in docs])
    # LLM 프롬프트
    prompt = f"""
    '{country}'를 여행지로 선택할 때의 단점(주의점, 불편한 점 등)을 알려주세요. 아래 검색 결과를 참고해 구체적으로 작성하고, 인용 근거가 있으면 함께 제시하세요. 2~3문단, 각 문단 100자 이내.
    [검색 결과]\n{context}
    """
    messages = [SystemMessage(content="당신은 여행 전문가입니다."), HumanMessage(content=prompt)]
    response = get_llm().invoke(messages)
    new_state = state.copy()
    new_state["cons"] = response.content
    new_state["contexts"] = new_state.get("contexts", {})
    new_state["contexts"][AgentType.CONS] = context
    new_state["docs"] = new_state.get("docs", {})
    new_state["docs"][AgentType.CONS] = [doc.page_content for doc in docs]
    return new_state

# 결론 생성 노드
def conclusion_agent(state: CountryReviewState) -> CountryReviewState:
    country = state["country"]
    pros = state.get("pros", "")
    cons = state.get("cons", "")
    # LLM 프롬프트
    prompt = f"""
    '{country}' 여행에 대한 장점과 단점을 종합해 결론(추천 여부, 요약 등)을 내려주세요. 아래 내용을 참고해 2~3문단, 각 문단 100자 이내로 작성하세요.
    [장점]\n{pros}\n[단점]\n{cons}
    """
    messages = [SystemMessage(content="당신은 여행 전문가입니다."), HumanMessage(content=prompt)]
    response = get_llm().invoke(messages)
    new_state = state.copy()
    new_state["conclusion"] = response.content
    return new_state

# 여행 코스 생성 노드
def itinerary_agent(state: CountryReviewState) -> CountryReviewState:
    country = state["country"]
    # RAG 검색 (여행 코스)
    docs = search_topic(country, AgentType.ITINERARY, f"{country} 여행 코스 추천 관광지 일정", k=3)
    context = "\n".join([doc.page_content for doc in docs])
    # LLM 프롬프트
    prompt = f"""
    '{country}' 여행을 위한 추천 여행 코스를 만들어주세요. 아래 검색 결과를 참고해 구체적으로 작성하고, 3-5일 일정으로 주요 관광지를 포함한 실용적인 코스를 제시하세요. 각 일차별로 주요 관광지와 활동을 명시해주세요.
    [검색 결과]\n{context}
    """
    messages = [SystemMessage(content="당신은 여행 전문가입니다."), HumanMessage(content=prompt)]
    response = get_llm().invoke(messages)
    new_state = state.copy()
    new_state["itinerary"] = response.content
    new_state["contexts"] = new_state.get("contexts", {})
    new_state["contexts"][AgentType.ITINERARY] = context
    new_state["docs"] = new_state.get("docs", {})
    new_state["docs"][AgentType.ITINERARY] = [doc.page_content for doc in docs]
    return new_state

# 대체 여행지 생성 노드
def alternatives_agent(state: CountryReviewState) -> CountryReviewState:
    country = state["country"]
    pros = state.get("pros", "")
    cons = state.get("cons", "")
    
    # RAG 검색 (대체 여행지)
    docs = search_topic(country, AgentType.ALTERNATIVES, f"{country} 대체 여행지 유사한 관광지", k=3)
    context = "\n".join([doc.page_content for doc in docs])
    
    # LLM 프롬프트
    prompt = f"""
    '{country}'와 비교할 만한 대체 여행지를 추천해주세요. 아래 검색 결과를 참고해 구체적으로 작성하고, 
    '{country}'의 장점과 단점을 고려하여 비슷한 매력이 있으면서도 다른 특징을 가진 3-5개의 대체 여행지를 제시하세요. 
    각 대체 여행지에 대해 간단한 설명과 함께 왜 추천하는지 이유를 포함해주세요.
    
    [현재 여행지 정보]
    장점: {pros}
    단점: {cons}
    
    [검색 결과]\n{context}
    """
    messages = [SystemMessage(content="당신은 여행 전문가입니다."), HumanMessage(content=prompt)]
    response = get_llm().invoke(messages)
    new_state = state.copy()
    new_state["alternatives"] = response.content
    new_state["contexts"] = new_state.get("contexts", {})
    new_state["contexts"][AgentType.ALTERNATIVES] = context
    new_state["docs"] = new_state.get("docs", {})
    new_state["docs"][AgentType.ALTERNATIVES] = [doc.page_content for doc in docs]
    return new_state
