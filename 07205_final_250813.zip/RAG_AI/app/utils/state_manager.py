import streamlit as st


def init_session_state():
    # 세션 상태 초기화
    if "app_mode" not in st.session_state:
        reset_session_state()


def reset_session_state():
    st.session_state.app_mode = False
    st.session_state.country = ""
    st.session_state.pros = ""
    st.session_state.cons = ""
    st.session_state.conclusion = ""
    st.session_state.itinerary = ""
    st.session_state.alternatives = ""
    st.session_state.docs = {}
    st.session_state.viewing_history = False
    st.session_state.show_share_popup = False
    # 사이드바 탭을 "여행국 조사" 탭으로 설정
    st.session_state.sidebar_tab = 0


def set_review_to_state(country, pros, cons, conclusion, docs):
    st.session_state.app_mode = True
    st.session_state.country = country
    st.session_state.pros = pros
    st.session_state.cons = cons
    st.session_state.conclusion = conclusion
    st.session_state.docs = docs
    st.session_state.viewing_history = True
