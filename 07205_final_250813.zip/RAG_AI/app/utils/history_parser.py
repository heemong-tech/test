def parse_history_message(message_content: str) -> dict:
    """이력에서 저장된 메시지를 파싱하여 개별 필드로 변환"""
    result = {
        "country": "",
        "pros": "",
        "cons": "",
        "conclusion": "",
        "itinerary": "",
        "alternatives": ""
    }
    
    lines = message_content.split('\n')
    current_section = None
    section_content = []
    
    for line in lines:
        line = line.strip()
        if line.startswith("장점:"):
            # 이전 섹션 저장
            if current_section and section_content:
                result[current_section] = '\n'.join(section_content).strip()
            current_section = "pros"
            section_content = [line.replace("장점:", "").strip()]
        elif line.startswith("단점:"):
            # 이전 섹션 저장
            if current_section and section_content:
                result[current_section] = '\n'.join(section_content).strip()
            current_section = "cons"
            section_content = [line.replace("단점:", "").strip()]
        elif line.startswith("결론:"):
            # 이전 섹션 저장
            if current_section and section_content:
                result[current_section] = '\n'.join(section_content).strip()
            current_section = "conclusion"
            section_content = [line.replace("결론:", "").strip()]
        elif line.startswith("추천 여행 코스:"):
            # 이전 섹션 저장
            if current_section and section_content:
                result[current_section] = '\n'.join(section_content).strip()
            current_section = "itinerary"
            section_content = []
        elif line.startswith("대체 여행지:"):
            # 이전 섹션 저장
            if current_section and section_content:
                result[current_section] = '\n'.join(section_content).strip()
            current_section = "alternatives"
            section_content = []
        elif current_section and line:
            # 현재 섹션에 내용 추가
            section_content.append(line)
    
    # 마지막 섹션 저장
    if current_section and section_content:
        result[current_section] = '\n'.join(section_content).strip()
    
    return result 