# 🌏 AI 여행지 조사 시스템

사용자가 입력한 여행지의 장단점을 AI로 조사하고, 결론과 추천 코스, 참조 정보를 제공하는 Streamlit 애플리케이션입니다.

## 주요 기능

- **여행지 조사**: 입력한 여행지의 장점, 단점, 결론 분석
- **추천 여행 코스**: AI가 추천하는 여행 일정
- **대체 여행지**: 유사한 여행지 추천
- **참조 데이터**: 조사에 사용된 웹 검색 결과
- **이력 관리**: 이전 조사 결과 저장 및 조회
- **이메일 공유**: 조사 결과를 이메일로 공유

## 설치 및 실행

### 1. 의존성 설치
```bash
pip install -r requirements.txt
```

### 2. 이메일 설정 (선택사항)
이메일 공유 기능을 사용하려면 환경변수를 설정하세요:

```bash
# Windows
set EMAIL_SENDER=your-email@gmail.com
set EMAIL_PASSWORD=your-app-password

# Linux/Mac
export EMAIL_SENDER=your-email@gmail.com
export EMAIL_PASSWORD=your-app-password
```

**Gmail 앱 비밀번호 설정 방법:**
1. Google 계정 설정 → 보안
2. 2단계 인증 활성화
3. 앱 비밀번호 생성
4. 생성된 16자리 비밀번호를 `EMAIL_PASSWORD`에 설정

### 3. 애플리케이션 실행
```bash
streamlit run app/main.py
```

## 사용 방법

1. **여행지 입력**: 사이드바에서 조사할 여행지를 입력
2. **조사 시작**: "조사 시작" 버튼 클릭
3. **결과 확인**: 장점, 단점, 결론, 추천 코스, 대체 여행지 확인
4. **참조 데이터**: "참조 데이터 보기"에서 원본 링크 확인
5. **이메일 공유**: "공유하기" 버튼으로 결과 공유
6. **이력 조회**: "조사 이력" 탭에서 이전 결과 확인

## 프로젝트 구조

```
RAG_AI/app/
├── main.py              # 메인 애플리케이션
├── components/          # UI 컴포넌트
│   ├── sidebar.py      # 사이드바
│   └── history.py      # 이력 관리
├── workflow/           # AI 워크플로우
│   ├── graph.py        # 워크플로우 그래프
│   ├── node.py         # AI 노드
│   └── state.py        # 상태 관리
├── database/           # 데이터베이스
│   ├── model.py        # 데이터 모델
│   ├── repository.py   # 데이터 접근
│   └── session.py      # 세션 관리
├── retrieval/          # 검색 및 검색
│   ├── search_service.py
│   └── vector_store.py
├── utils/              # 유틸리티
│   ├── state_manager.py
│   └── history_parser.py
└── config/             # 설정
    └── email_config.py
```

## 기술 스택

- **Frontend**: Streamlit
- **AI/ML**: LangChain, LangGraph
- **Database**: SQLite, SQLAlchemy
- **Search**: DuckDuckGo Search
- **Email**: SMTP (Gmail)

## 라이선스

MIT License 